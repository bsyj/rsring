package com.moremod.capability;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.energy.IEnergyStorage;

public interface IRsRingCapability {
    // 绑定RS终端位置
    void bindTerminal(World world, BlockPos pos);
    BlockPos getTerminalPos();
    int getTerminalDimension();
    World getTerminalWorld();
    boolean isBound();
    
    // 开启/关闭功能
    void setEnabled(boolean enabled);
    boolean isEnabled();
    
    // 能量管理
    IEnergyStorage getEnergyStorage();
    
    // 获取饰品实例的副本
    IRsRingCapability copy();
}