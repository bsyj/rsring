package com.moremod.proxy;

public class CommonProxy {
    public void preInit() {}
    public void init() {}
    public void postInit() {}
}