package com.moremod.network;

import com.moremod.capability.IRsRingCapability;
import com.moremod.capability.RsRingCapability;
import com.moremod.item.ItemRsRing;
import com.moremod.item.ItemChestRing;
import com.moremod.rsring.RsRingMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/**
 * 客户端发往服务器的切换戒指功能数据包
 */
public class PacketToggleRsRing implements IMessage {

    public PacketToggleRsRing() {}

    @Override
    public void fromBytes(ByteBuf buf) {}

    @Override
    public void toBytes(ByteBuf buf) {}

    public static class Handler implements IMessageHandler<PacketToggleRsRing, IMessage> {
        @Override
        public IMessage onMessage(PacketToggleRsRing message, MessageContext ctx) {
            EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(() -> {
                ItemStack ringStack = findAnyRing(player);
                if (!ringStack.isEmpty()) {
                    IRsRingCapability capability = ringStack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
                    if (capability != null) {
                        boolean newState = !capability.isEnabled();
                        capability.setEnabled(newState);
                        ItemRsRing.syncCapabilityToStack(ringStack, capability);
                        markBaublesDirtyIfNeeded(player, ringStack);
                        String status = newState ? "已开启" : "已关闭";
                        String name = ringStack.getItem() instanceof ItemChestRing ? "箱子戒指" : "RS戒指";
                        player.sendMessage(new TextComponentString(TextFormatting.GREEN + name + ": " + status));
                    }
                } else {
                    player.sendMessage(new TextComponentString(TextFormatting.RED + "未找到戒指"));
                }
            });
            return null;
        }

        private ItemStack findAnyRing(net.minecraft.entity.player.EntityPlayer player) {
            ItemStack r = findRing(player, ItemRsRing.class);
            if (!r.isEmpty()) return r;
            return findRing(player, ItemChestRing.class);
        }

        private ItemStack findRing(net.minecraft.entity.player.EntityPlayer player, Class<? extends net.minecraft.item.Item> ringClass) {
            if (!player.getHeldItemMainhand().isEmpty() && ringClass.isInstance(player.getHeldItemMainhand().getItem())) {
                return player.getHeldItemMainhand();
            }
            if (!player.getHeldItemOffhand().isEmpty() && ringClass.isInstance(player.getHeldItemOffhand().getItem())) {
                return player.getHeldItemOffhand();
            }
            if (net.minecraftforge.fml.common.Loader.isModLoaded("baubles")) {
                try {
                    Class<?> apiClass = Class.forName("baubles.api.BaublesApi");
                    Object handler = apiClass.getMethod("getBaublesHandler", net.minecraft.entity.player.EntityPlayer.class).invoke(null, player);
                    if (handler instanceof net.minecraft.inventory.IInventory) {
                        net.minecraft.inventory.IInventory baubles = (net.minecraft.inventory.IInventory) handler;
                        for (int i = 0; i < baubles.getSizeInventory(); i++) {
                            ItemStack stack = baubles.getStackInSlot(i);
                            if (!stack.isEmpty() && ringClass.isInstance(stack.getItem())) return stack;
                        }
                    }
                } catch (Throwable ignored) {}
            }
            for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
                ItemStack stack = player.inventory.getStackInSlot(i);
                if (!stack.isEmpty() && ringClass.isInstance(stack.getItem())) return stack;
            }
            return ItemStack.EMPTY;
        }

        private void markBaublesDirtyIfNeeded(net.minecraft.entity.player.EntityPlayer player, net.minecraft.item.ItemStack ringStack) {
            if (!net.minecraftforge.fml.common.Loader.isModLoaded("baubles")) return;
            try {
                Object handler = Class.forName("baubles.api.BaublesApi").getMethod("getBaublesHandler", net.minecraft.entity.player.EntityPlayer.class).invoke(null, player);
                if (handler instanceof net.minecraft.inventory.IInventory) {
                    ((net.minecraft.inventory.IInventory) handler).markDirty();
                }
            } catch (Throwable ignored) {}
        }
    }
}
