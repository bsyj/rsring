package com.moremod.rsring;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.Logger;

import com.moremod.capability.IRsRingCapability;
import com.moremod.capability.RsRingCapability;
import com.moremod.event.CommonEventHandler;
import com.moremod.item.ItemRsRing;
import com.moremod.item.ItemChestRing;
import com.moremod.network.PacketToggleRsRing;

@Mod(modid = RsRingMod.MODID, name = RsRingMod.NAME, version = RsRingMod.VERSION)
public class RsRingMod
{
    public static final String MODID = "rsring";
    public static final String NAME = "RS Ring";
    public static final String VERSION = "1.0";

    private static Logger logger;

    // 注册的物品
    public static ItemRsRing rsRing;
    public static ItemChestRing chestRing;
    public static SimpleNetworkWrapper network;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
        logger = event.getModLog();

        // 初始化物品（ItemRsRing 构造时已设置 setRegistryName）
        rsRing = new ItemRsRing();
        ForgeRegistries.ITEMS.register(rsRing);
        chestRing = new ItemChestRing();
        ForgeRegistries.ITEMS.register(chestRing);

        // 注册能力
        CapabilityManager.INSTANCE.register(IRsRingCapability.class, new RsRingCapability.RsRingStorage(), RsRingCapability::new);

        // 注册网络通道
        network = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        network.registerMessage(PacketToggleRsRing.Handler.class, PacketToggleRsRing.class, 0, Side.SERVER);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        // 注册事件处理器
        MinecraftForge.EVENT_BUS.register(new CommonEventHandler());
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        // 后期初始化
    }

    @EventHandler
    public void serverLoad(FMLServerStartingEvent event) {
        // 服务器启动事件
    }
}
