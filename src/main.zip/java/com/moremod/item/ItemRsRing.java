package com.moremod.item;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import java.util.List;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.energy.IEnergyStorage;
import com.moremod.capability.IRsRingCapability;
import com.moremod.capability.RsRingCapability;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;
import com.moremod.integration.RsIntegration;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.Optional;
import baubles.api.IBauble;
import baubles.api.BaubleType;
import org.lwjgl.input.Keyboard;

@Optional.Interface(iface = "baubles.api.IBauble", modid = "baubles")
public class ItemRsRing extends Item implements IBauble {
    
    public ItemRsRing() {
        super();
        this.setTranslationKey("rsring");
        this.setRegistryName(new ResourceLocation("rsring", "rsring"));
        this.setMaxStackSize(1);
        this.setCreativeTab(CreativeTabs.MISC);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
        IRsRingCapability cap = stack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
        if (cap == null) return;

        IEnergyStorage energy = cap.getEnergyStorage();
        tooltip.add(TextFormatting.GRAY + "能量: " + TextFormatting.YELLOW + formatFe(energy.getEnergyStored()) + TextFormatting.GRAY + " / " + formatFe(energy.getMaxEnergyStored()) + " FE");
        tooltip.add(TextFormatting.GRAY + "状态: " + (cap.isEnabled() ? TextFormatting.GREEN + "已开启" : TextFormatting.RED + "已关闭"));
        if (cap.isBound()) {
            tooltip.add(TextFormatting.GRAY + "绑定: " + TextFormatting.AQUA + cap.getTerminalPos().getX() + ", " + cap.getTerminalPos().getY() + ", " + cap.getTerminalPos().getZ());
            tooltip.add(TextFormatting.GRAY + "维度: " + TextFormatting.AQUA + getDimensionName(cap.getTerminalDimension()));
        } else {
            tooltip.add(TextFormatting.GRAY + "未绑定");
        }
        boolean showDetail = flagIn.isAdvanced() || Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
        if (!showDetail) {
            tooltip.add(TextFormatting.DARK_GRAY + "按住 " + TextFormatting.YELLOW + "Shift" + TextFormatting.DARK_GRAY + " 查看功能介绍 (F3+H 始终显示)");
        } else {
            tooltip.add("");
            tooltip.add(TextFormatting.GOLD + "功能介绍:");
            tooltip.add(TextFormatting.GRAY + "  · 吸收8格内掉落物到RS网络");
            tooltip.add(TextFormatting.GRAY + "  · 支持跨维度传输");
            tooltip.add(TextFormatting.GRAY + "  · 1 FE/每个物品");
            tooltip.add("");
            tooltip.add(TextFormatting.GOLD + "使用方法:");
            tooltip.add(TextFormatting.GRAY + "  1. 蹲下+右键RS终端/接口/控制器绑定");
            tooltip.add(TextFormatting.GRAY + "  2. 用FE充能器充电 (最大10M FE)");
            tooltip.add(TextFormatting.GRAY + "  3. 按K键开启/关闭吸收功能");
            tooltip.add(TextFormatting.GRAY + "  4. 戒指在背包/饰品栏/手持均可生效");
        }
    }

    @Override
    public boolean showDurabilityBar(ItemStack stack) {
        IRsRingCapability cap = stack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
        if (cap == null) return false;
        int stored = cap.getEnergyStorage().getEnergyStored();
        int max = cap.getEnergyStorage().getMaxEnergyStored();
        return max > 0 && stored < max;
    }

    @Override
    public double getDurabilityForDisplay(ItemStack stack) {
        IRsRingCapability cap = stack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
        if (cap == null) return 1.0;
        int stored = cap.getEnergyStorage().getEnergyStored();
        int max = cap.getEnergyStorage().getMaxEnergyStored();
        if (max <= 0) return 0.0;
        return 1.0 - ((double) stored / (double) max);
    }

    private static String formatFe(int fe) {
        if (fe >= 1_000_000) return String.format("%.1fM", fe / 1_000_000.0);
        if (fe >= 1_000) return String.format("%.1fK", fe / 1_000.0);
        return String.valueOf(fe);
    }

    private static String getDimensionName(int dim) {
        switch (dim) {
            case 0: return "主世界";
            case -1: return "下界";
            case 1: return "末地";
            default: return "维度 " + dim;
        }
    }

    @Override
    @Optional.Method(modid = "baubles")
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.RING;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        
        if (!world.isRemote) {
            IRsRingCapability capability = stack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
            if (capability != null) {
                String msg = capability.isBound()
                    ? "已绑定 | 能量: " + capability.getEnergyStorage().getEnergyStored() + "/" + capability.getEnergyStorage().getMaxEnergyStored() + " FE | " + (capability.isEnabled() ? "已开启" : "已关闭")
                    : "蹲下 + 右键RS终端(Grid)绑定 | 按K切换功能";
                player.sendMessage(new TextComponentString(msg));
            }
        }
        
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    // 每tick调用（手持/背包/饰品栏佩戴时均生效）
    public void onWornTick(ItemStack itemstack, EntityLivingBase player) {
        if (player.world.isRemote || !(player instanceof EntityPlayer)) return;
        
        EntityPlayer entityPlayer = (EntityPlayer) player;
        IRsRingCapability capability = itemstack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
        
        // 同步 capability 到 stack NBT，防止移动时丢失
        if (capability != null && capability.isBound()) {
            syncCapabilityToStack(itemstack, capability);
        }
        
        if (capability == null || !capability.isEnabled() || !capability.isBound()) return;
        
        IEnergyStorage energyStorage = capability.getEnergyStorage();
        if (energyStorage.getEnergyStored() < 1) return;
        
        // 每5tick执行一次吸收，降低性能消耗
        if (entityPlayer.ticksExisted % 5 == 0) {
            absorbItemsToTerminal(entityPlayer, capability);
        }
    }

    public static void syncCapabilityToStack(ItemStack stack, IRsRingCapability cap) {
        if (cap == null || RsRingCapability.RS_RING_CAPABILITY == null) return;
        net.minecraft.nbt.NBTBase nbt = RsRingCapability.RS_RING_CAPABILITY.getStorage().writeNBT(RsRingCapability.RS_RING_CAPABILITY, cap, null);
        if (nbt instanceof net.minecraft.nbt.NBTTagCompound) {
            if (!stack.hasTagCompound()) stack.setTagCompound(new net.minecraft.nbt.NBTTagCompound());
            stack.getTagCompound().setTag("RsRingData", (net.minecraft.nbt.NBTTagCompound) nbt);
        }
    }

    @Override
    public net.minecraft.nbt.NBTTagCompound getNBTShareTag(ItemStack stack) {
        net.minecraft.nbt.NBTTagCompound tag = stack.getTagCompound() != null ? stack.getTagCompound().copy() : new net.minecraft.nbt.NBTTagCompound();
        IRsRingCapability cap = stack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
        if (cap != null && RsRingCapability.RS_RING_CAPABILITY != null) {
            net.minecraft.nbt.NBTBase capNbt = RsRingCapability.RS_RING_CAPABILITY.getStorage().writeNBT(RsRingCapability.RS_RING_CAPABILITY, cap, null);
            if (capNbt instanceof net.minecraft.nbt.NBTTagCompound) {
                tag.setTag("RsRingData", (net.minecraft.nbt.NBTTagCompound) capNbt);
            }
        }
        return tag;
    }

    @Override
    public void readNBTShareTag(ItemStack stack, net.minecraft.nbt.NBTTagCompound nbt) {
        stack.setTagCompound(nbt);
        if (nbt != null && nbt.hasKey("RsRingData") && RsRingCapability.RS_RING_CAPABILITY != null) {
            net.minecraft.nbt.NBTTagCompound data = nbt.getCompoundTag("RsRingData");
            IRsRingCapability cap = stack.getCapability(RsRingCapability.RS_RING_CAPABILITY, null);
            if (cap != null) {
                RsRingCapability.RS_RING_CAPABILITY.getStorage().readNBT(RsRingCapability.RS_RING_CAPABILITY, cap, null, data);
            }
        }
    }

    public ICapabilityProvider initCapabilities(ItemStack stack, net.minecraft.nbt.NBTTagCompound nbt) {
        RsRingCapability.RsRingCapabilityProvider provider = new RsRingCapability.RsRingCapabilityProvider();
        // 从 NBT 恢复，兼容 ForgeCaps 及备用存储
        net.minecraft.nbt.NBTTagCompound data = nbt;
        if ((data == null || data.getKeySet().isEmpty()) && stack.getTagCompound() != null) {
            if (stack.getTagCompound().hasKey("RsRingData")) {
                data = stack.getTagCompound().getCompoundTag("RsRingData");
            } else if (stack.getTagCompound().hasKey("ForgeCaps")) {
                net.minecraft.nbt.NBTTagCompound caps = stack.getTagCompound().getCompoundTag("ForgeCaps");
                if (caps.hasKey("rsring:rsring")) data = caps.getCompoundTag("rsring:rsring");
            }
        }
        provider.initFromNBT(data);
        return provider;
    }

    
    // 物品吸收方法
    private void absorbItemsToTerminal(EntityPlayer player, IRsRingCapability capability) {
        // 检查是否已绑定终端
        if (!capability.isBound()) {
            return;
        }
        
        // 获取终端位置和世界（支持跨纬度）
        World terminalWorld = capability.getTerminalWorld();
        BlockPos terminalPos = capability.getTerminalPos();
        if (terminalWorld == null || terminalPos == null) return;
        // 确保区块已加载（跨维度时目标维度可能未加载）
        if (!terminalWorld.isBlockLoaded(terminalPos)) {
            terminalWorld.getChunk(terminalPos);
            if (!terminalWorld.isBlockLoaded(terminalPos)) return;
        }
        
        // 在玩家周围搜索掉落物
        java.util.List<net.minecraft.entity.item.EntityItem> items = player.world.getEntitiesWithinAABB(
            net.minecraft.entity.item.EntityItem.class,
            player.getEntityBoundingBox().grow(8.0) // 8格范围
        );
        
        IEnergyStorage energyStorage = capability.getEnergyStorage();
        for (net.minecraft.entity.item.EntityItem item : items) {
            if (item.isDead) continue;
            
            ItemStack itemStack = item.getItem();
            if (itemStack.isEmpty() || energyStorage.getEnergyStored() < 1) continue;
            
            int inserted = insertItemIntoTerminal(terminalWorld, terminalPos, itemStack);
            if (inserted > 0 && energyStorage.getEnergyStored() >= inserted) {
                energyStorage.extractEnergy(inserted, false);
                if (itemStack.isEmpty()) item.setDead();
            }
        }
    }
    
    // 插入物品到RS网络，返回实际插入的数量（1 FE/每个物品）
    // 优先尝试 RS API（Controller/Grid），回退到 IItemHandler（Interface）
    private int insertItemIntoTerminal(World world, BlockPos pos, ItemStack stack) {
        if (world == null || pos == null || stack.isEmpty()) return 0;
        TileEntity te = world.getTileEntity(pos);
        if (te == null) return 0;

        // 1. 尝试 RS 网络 API（适用于 Controller、Grid 等）
        if (te.getClass().getName().contains("refinedstorage")) {
            int rsInserted = RsIntegration.insertIntoNetwork(te, stack);
            if (rsInserted > 0) return rsInserted;
        }

        // 2. 标准 IItemHandler（Interface 等），逐个 handler 尝试
        for (EnumFacing f : EnumFacing.VALUES) {
            int inserted = tryInsertToHandler(te, f, stack);
            if (inserted > 0) return inserted;
        }
        return tryInsertToHandler(te, null, stack);
    }

    private int tryInsertToHandler(TileEntity te, EnumFacing facing, ItemStack stack) {
        if (!te.hasCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, facing)) return 0;
        IItemHandler h = te.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, facing);
        if (h == null || h.getSlots() == 0) return 0;
        int before = stack.getCount();
        ItemStack remainder = ItemHandlerHelper.insertItemStacked(h, stack.copy(), false);
        int inserted = before - remainder.getCount();
        if (inserted > 0) stack.setCount(remainder.getCount());
        return inserted;
    }
    
    @SideOnly(Side.CLIENT)
    public void onPlayerBaubleRender(ItemStack stack, EntityPlayer player, float partialTicks) {
        GlStateManager.pushMatrix();
        
        // 设置渲染变换
        Minecraft.getMinecraft().getRenderItem().renderItem(stack, ItemCameraTransforms.TransformType.NONE);
        
        GlStateManager.popMatrix();
    }
}