package com.moremod.integration;

import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;

/**
 * Refined Storage 集成 - 通过反射调用 RS API
 * RS 1.12 可能使用不同包名：com.raoulvdberge 或 com.refinedmods
 */
public class RsIntegration {

    public static int insertIntoNetwork(TileEntity te, ItemStack stack) {
        if (te == null || stack.isEmpty()) return 0;

        // 尝试多种 RS API 变体
        String[] actionClasses = {
            "com.raoulvdberge.refinedstorage.apiimpl.storage.Action",
            "com.refinedmods.refinedstorage.apiimpl.storage.Action",
            "com.raoulvdberge.refinedstorage.api.storage.Action"
        };

        for (String actionClassName : actionClasses) {
            int result = tryInsert(te, stack, actionClassName);
            if (result > 0) return result;
        }

        return 0;
    }

    private static int tryInsert(TileEntity te, ItemStack stack, String actionClassName) {
        try {
            Object node = invoke(te, "getNode");
            if (node == null) return 0;

            Object network = invoke(node, "getNetwork");
            if (network == null) return 0;

            Class<?> actionClass = Class.forName(actionClassName);
            Object performAction = getEnumConstant(actionClass, "PERFORM");
            if (performAction == null) return 0;

            // 尝试 insertItem(ItemStack, int, Action)
            Object remainder = network.getClass().getMethod("insertItem", ItemStack.class, int.class, actionClass)
                .invoke(network, stack.copy(), stack.getCount(), performAction);
            return processRemainder(stack, remainder);

        } catch (Throwable t) {
            try {
                // 尝试 insertItem(ItemStack) - 单参数
                Object node = invoke(te, "getNode");
                if (node == null) return 0;
                Object network = invoke(node, "getNetwork");
                if (network == null) return 0;

                Object remainder = network.getClass().getMethod("insertItem", ItemStack.class)
                    .invoke(network, stack.copy());
                return processRemainder(stack, remainder);
            } catch (Throwable ignored) {}
        }
        return 0;
    }

    private static int processRemainder(ItemStack stack, Object remainder) {
        if (remainder instanceof ItemStack) {
            int inserted = stack.getCount() - ((ItemStack) remainder).getCount();
            if (inserted > 0) {
                stack.shrink(inserted);
                return inserted;
            }
        }
        return 0;
    }

    private static Object getEnumConstant(Class<?> cls, String name) {
        try {
            for (Object c : cls.getEnumConstants()) {
                if (name.equals(c.toString())) return c;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static Object invoke(Object obj, String method) {
        try {
            return obj.getClass().getMethod(method).invoke(obj);
        } catch (Throwable t) {
            return null;
        }
    }
}
