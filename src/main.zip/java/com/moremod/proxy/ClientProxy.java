package com.moremod.proxy;

import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
import com.moremod.rsring.RsRingMod;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.model.ModelLoader;

@Mod.EventBusSubscriber(modid = RsRingMod.MODID, value = Side.CLIENT)
public class ClientProxy {

    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        // 注册 RS Ring 模型
        ModelLoader.setCustomModelResourceLocation(
            RsRingMod.rsRing, 
            0, 
            new ModelResourceLocation(RsRingMod.rsRing.getRegistryName(), "inventory")
        );
        
        // 注册 Chest Ring 模型
        ModelLoader.setCustomModelResourceLocation(
            RsRingMod.chestRing, 
            0, 
            new ModelResourceLocation(RsRingMod.chestRing.getRegistryName(), "inventory")
        );
    }
}